const express = require('express');
const { exec } = require('child_process');
const app = express();

const SECRET = "saymyname-heisenberg";

app.use(express.json());

// ✅ Welcome Screen Route
app.get('/', (req, res) => {
    res.send(`
        <html>
            <head>
                <title>Instantly Trigger Server</title>
                <style>
                    body {
                        background-color: #f4f4f4;
                        font-family: Arial, sans-serif;
                        text-align: center;
                        padding-top: 50px;
                    }
                    h1 {
                        color: #333;
                    }
                    p {
                        color: #555;
                        font-size: 18px;
                    }
                </style>
            </head>
            <body>
                <h1>🚀 Instantly Trigger API</h1>
                <p>Use <code>/trigger</code> to start the script.</p>
                <p>Use <code>/stop</code> to stop the script.</p>
            </body>
        </html>
    `);
});

app.post('/trigger', (req, res) => {
    if (req.body.secret !== SECRET) return res.status(403).send("Forbidden");

    exec('/home/atozvm2/Desktop/Instantly_G/run_instanly.sh', (err, stdout, stderr) => {
        if (err) return res.status(500).send(stderr);
        res.send("✅ Script executed!");
    });
});

app.post('/stop', (req, res) => {
    console.log("📩 /stop endpoint hit");

    const receivedSecret = req.body.secret;
    console.log("🔑 Received secret:", receivedSecret);

    if (receivedSecret !== SECRET) {
        console.warn("❌ Unauthorized attempt with wrong secret");
        return res.status(403).send("Forbidden");
    }

    console.log("✅ Secret verified. Running stop_instanly.sh...");

    exec('/home/atozvm2/Desktop/Instantly_G/stop_instanly.sh', (err, stdout, stderr) => {
        if (err) {
            console.error("❗ Error executing stop_instanly.sh:", err);
            return res.status(500).send(stderr);
        }

        console.log("🛑 stop_instanly.sh executed successfully.");
        console.log("STDOUT:", stdout);
        console.log("STDERR:", stderr);
        res.send("🛑 Script stopped!");
    });
});

app.listen(8081, () => console.log("🚀server running on port 8081"));
